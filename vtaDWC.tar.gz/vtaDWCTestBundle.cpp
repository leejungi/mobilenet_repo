

#include "vta/runtime.h"
#include "VTABundle.h"
#include "VTADWC.h"
#include <time.h>
#include <iostream>
#include <fstream>
#include "vtaDWCTestBundle.h"
SymbolTableEntry symbolTableEntry_vtaDWCTestBundle[2]={{"inputP",0,401408,'1'},{"outP",401408,401408,'1'}};
BundleConfig vtaDWCTestBundle_config = {416, 802816, 0, 64, 2, symbolTableEntry_vtaDWCTestBundle};
int8_t* filterP;
int32_t* biasP;
extern VTACommandHandle vtaCmdH;

void vtaDWCTestBundle_load_module(uint8_t *constantWeight){
  filterP = (int8_t *)VTABufferAlloc(512);
  DWC_transpose_nchw2vtak((int8_t *)(constantWeight + 0), (int8_t*) VTABufferGetVirtAddr(filterP), 32, 3, 3, 16);
  biasP = (int32_t *) VTABufferAlloc(2048);
  DWC_transpose_bias((int32_t *)(constantWeight + 288), (int32_t*) VTABufferGetVirtAddr(biasP), 32);
}

void vtaDWCTestBundle_destroy_module(){
  VTABufferFree(filterP);
  VTABufferFree(biasP);
}
int vtaDWCTestBundle(uint8_t *constantWeight, uint8_t *mutableWeight, uint8_t *activations){

  //Run convolution : conv
  int8_t* inputP = (int8_t*)mutableWeight + 0;
  int8_t* outP = (int8_t*)mutableWeight + 401408;
  int8_t* conv_input_transpose = (int8_t *)VTABufferAlloc(6422528);
  DWC_transpose_nhwc2vtaio(inputP, (int8_t* )VTABufferGetVirtAddr(conv_input_transpose), 1, 112, 112, 32, 3, 3, 112, 112, 16, 12544, 1, 1);
  int8_t* conv_output_bef_transpose = (int8_t *)malloc(401408);
  depthwise_convolution(conv_input_transpose, filterP, (int32_t *)biasP, conv_output_bef_transpose, 1, 112, 112, 32, 3, 3, 1, 1, 0, 1, 8, 112, 112, 16, 12544, vtaCmdH);
  DWC_transpose_vtaio2nhwc(conv_output_bef_transpose, outP, 1, 32, 112, 112, 12544 );
  VTABufferFree(conv_input_transpose);
  free(conv_output_bef_transpose);
  return 0;
}